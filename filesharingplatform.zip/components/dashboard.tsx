"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  FileIcon,
  FolderIcon,
  HomeIcon,
  SearchIcon,
  Share2Icon,
  StarIcon,
  TrashIcon,
  UsersIcon,
  ClockIcon,
  MoreVerticalIcon,
  PlusIcon,
  LogOutIcon,
} from "lucide-react"
import FileUploader from "@/components/file-uploader"

// Mock file data
const initialFiles = [
  {
    id: "1",
    name: "Project Proposal.pdf",
    type: "pdf",
    size: "2.4 MB",
    modified: "2023-05-10T14:30:00",
    starred: false,
    shared: true,
    owner: "you",
  },
  {
    id: "2",
    name: "Meeting Notes.docx",
    type: "docx",
    size: "1.2 MB",
    modified: "2023-05-09T10:15:00",
    starred: true,
    shared: false,
    owner: "you",
  },
  {
    id: "3",
    name: "Budget Spreadsheet.xlsx",
    type: "xlsx",
    size: "3.5 MB",
    modified: "2023-05-08T16:45:00",
    starred: false,
    shared: true,
    owner: "you",
  },
  {
    id: "4",
    name: "Team Photo.jpg",
    type: "jpg",
    size: "5.1 MB",
    modified: "2023-05-07T09:20:00",
    starred: false,
    shared: false,
    owner: "you",
  },
]

// Mock groups data
const initialGroups = [
  { id: "1", name: "Marketing Team", members: 5 },
  { id: "2", name: "Development Team", members: 8 },
  { id: "3", name: "Executive Board", members: 3 },
]

export default function Dashboard() {
  const router = useRouter()
  const { toast } = useToast()
  const [files, setFiles] = useState(initialFiles)
  const [groups, setGroups] = useState(initialGroups)
  const [activeTab, setActiveTab] = useState("my-files")
  const [searchQuery, setSearchQuery] = useState("")
  const [showCreateGroup, setShowCreateGroup] = useState(false)
  const [newGroupName, setNewGroupName] = useState("")
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [shareEmail, setShareEmail] = useState("")
  const [selectedFile, setSelectedFile] = useState<any>(null)

  // Filter files based on active tab and search query
  const filteredFiles = files.filter((file) => {
    const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase())

    switch (activeTab) {
      case "my-files":
        return matchesSearch && file.owner === "you"
      case "shared":
        return matchesSearch && file.shared
      case "starred":
        return matchesSearch && file.starred
      case "recent":
        // For demo, we'll just show all files in recent
        return matchesSearch
      case "trash":
        // For demo, we'll just show no files in trash
        return false
      default:
        return matchesSearch
    }
  })

  const handleFileUpload = (newFiles: any[]) => {
    // Create file objects for the newly uploaded files
    const uploadedFiles = newFiles.map((file, index) => ({
      id: `new-${Date.now()}-${index}`,
      name: file.name,
      type: file.name.split(".").pop() || "unknown",
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      modified: new Date().toISOString(),
      starred: false,
      shared: false,
      owner: "you",
    }))

    setFiles([...files, ...uploadedFiles])

    toast({
      title: "Files uploaded successfully",
      description: `${uploadedFiles.length} file(s) uploaded`,
    })
  }

  const handleStarFile = (fileId: string) => {
    setFiles(files.map((file) => (file.id === fileId ? { ...file, starred: !file.starred } : file)))
  }

  const handleDeleteFile = (fileId: string) => {
    // In a real app, you might move to trash instead of deleting
    setFiles(files.filter((file) => file.id !== fileId))

    toast({
      title: "File deleted",
      description: "The file has been moved to trash",
    })
  }

  const handleShareFile = (file: any) => {
    setSelectedFile(file)
    setShowShareDialog(true)
  }

  const handleShareSubmit = () => {
    if (!shareEmail) {
      toast({
        title: "Error",
        description: "Please enter an email address",
        variant: "destructive",
      })
      return
    }

    // Update the file to mark it as shared
    setFiles(files.map((file) => (file.id === selectedFile?.id ? { ...file, shared: true } : file)))

    toast({
      title: "File shared",
      description: `Shared with ${shareEmail}`,
    })

    setShareEmail("")
    setShowShareDialog(false)
  }

  const handleCreateGroup = () => {
    if (!newGroupName) {
      toast({
        title: "Error",
        description: "Please enter a group name",
        variant: "destructive",
      })
      return
    }

    const newGroup = {
      id: `group-${Date.now()}`,
      name: newGroupName,
      members: 1,
    }

    setGroups([...groups, newGroup])
    setNewGroupName("")
    setShowCreateGroup(false)

    toast({
      title: "Group created",
      description: `${newGroupName} has been created`,
    })
  }

  const handleLogout = () => {
    router.push("/")
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const getFileIcon = (fileType: string) => {
    return <FileIcon className="h-8 w-8 text-orange-500" />
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-orange-600">FileShare</h1>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <nav className="space-y-1">
            <Button
              variant={activeTab === "my-files" ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("my-files")}
            >
              <HomeIcon className="mr-2 h-4 w-4" />
              My Files
            </Button>
            <Button
              variant={activeTab === "shared" ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("shared")}
            >
              <Share2Icon className="mr-2 h-4 w-4" />
              Shared
            </Button>
            <Button
              variant={activeTab === "recent" ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("recent")}
            >
              <ClockIcon className="mr-2 h-4 w-4" />
              Recent
            </Button>
            <Button
              variant={activeTab === "starred" ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("starred")}
            >
              <StarIcon className="mr-2 h-4 w-4" />
              Starred
            </Button>
            <Button
              variant={activeTab === "trash" ? "secondary" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("trash")}
            >
              <TrashIcon className="mr-2 h-4 w-4" />
              Trash
            </Button>
          </nav>

          <div className="mt-8">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-semibold text-gray-600">Groups</h2>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setShowCreateGroup(true)}>
                <PlusIcon className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              <Button
                variant={activeTab === "groups" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("groups")}
              >
                <UsersIcon className="mr-2 h-4 w-4" />
                All Groups
              </Button>
              {groups.map((group) => (
                <Button
                  key={group.id}
                  variant="ghost"
                  className="w-full justify-start pl-8 text-sm"
                  onClick={() => setActiveTab(`group-${group.id}`)}
                >
                  {group.name}
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-gray-200">
          <Button variant="ghost" className="w-full justify-start text-red-500" onClick={handleLogout}>
            <LogOutIcon className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="relative w-full max-w-md">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search files..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="ml-4">
              <FileUploader onUpload={handleFileUpload} />
            </div>
          </div>
        </header>

        {/* Content area */}
        <main className="flex-1 overflow-auto p-6 bg-gray-50">
          {/* Page title */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">
              {activeTab === "my-files" && "My Files"}
              {activeTab === "shared" && "Shared Files"}
              {activeTab === "recent" && "Recent Files"}
              {activeTab === "starred" && "Starred Files"}
              {activeTab === "trash" && "Trash"}
              {activeTab === "groups" && "All Groups"}
              {activeTab.startsWith("group-") && groups.find((g) => `group-${g.id}` === activeTab)?.name}
            </h1>
            <p className="text-gray-500 mt-1">
              {activeTab === "my-files" && "Files you have uploaded"}
              {activeTab === "shared" && "Files shared with you or by you"}
              {activeTab === "recent" && "Recently accessed files"}
              {activeTab === "starred" && "Your favorite files"}
              {activeTab === "trash" && "Deleted files (kept for 30 days)"}
              {activeTab === "groups" && "Collaborate with your teams"}
              {activeTab.startsWith("group-") && "Share and collaborate on files"}
            </p>
          </div>

          {/* Files grid or groups list */}
          {activeTab === "groups" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groups.map((group) => (
                <Card key={group.id} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-orange-100 p-3 rounded-full">
                        <UsersIcon className="h-6 w-6 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">{group.name}</h3>
                        <p className="text-sm text-gray-500">{group.members} members</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 px-6 py-3">
                    <Button
                      variant="ghost"
                      className="text-orange-600"
                      onClick={() => setActiveTab(`group-${group.id}`)}
                    >
                      Open Group
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredFiles.length > 0 ? (
                <TooltipProvider>
                  {filteredFiles.map((file) => (
                    <Card key={file.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            {getFileIcon(file.type)}
                            <div>
                              <h3 className="font-medium truncate max-w-[180px]" title={file.name}>
                                {file.name}
                              </h3>
                              <p className="text-xs text-gray-500">
                                {file.size} • {formatDate(file.modified)}
                              </p>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreVerticalIcon className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleShareFile(file)}>
                                <Share2Icon className="mr-2 h-4 w-4" />
                                Share
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStarFile(file.id)}>
                                <StarIcon className="mr-2 h-4 w-4" />
                                {file.starred ? "Unstar" : "Star"}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDeleteFile(file.id)}>
                                <TrashIcon className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardContent>
                      <CardFooter className="bg-gray-50 px-4 py-2 flex justify-between">
                        <div className="flex space-x-2">
                          {file.shared && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                                  <Share2Icon className="h-3.5 w-3.5 text-gray-500" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Shared</TooltipContent>
                            </Tooltip>
                          )}
                          {file.starred && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                                  <StarIcon className="h-3.5 w-3.5 text-yellow-500" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Starred</TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 uppercase">{file.type}</span>
                      </CardFooter>
                    </Card>
                  ))}
                </TooltipProvider>
              ) : (
                <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                  <FolderIcon className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">No files found</h3>
                  <p className="text-gray-500 mt-1">
                    {activeTab === "my-files" && "Upload files to get started"}
                    {activeTab === "shared" && "No files have been shared with you yet"}
                    {activeTab === "recent" && "You haven't accessed any files recently"}
                    {activeTab === "starred" && "Star files to add them to this list"}
                    {activeTab === "trash" && "Your trash is empty"}
                    {activeTab.startsWith("group-") && "Share files with this group to get started"}
                  </p>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Create Group Dialog */}
      <Dialog open={showCreateGroup} onOpenChange={setShowCreateGroup}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Group</DialogTitle>
            <DialogDescription>Create a group to share files with multiple people at once.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="group-name" className="text-sm font-medium">
                Group Name
              </label>
              <Input
                id="group-name"
                placeholder="e.g., Marketing Team"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateGroup(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateGroup} className="bg-orange-600 hover:bg-orange-700">
              Create Group
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Share File Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share File</DialogTitle>
            <DialogDescription>Share "{selectedFile?.name}" with others by email.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="share-email" className="text-sm font-medium">
                Email Address
              </label>
              <Input
                id="share-email"
                placeholder="name@example.com"
                value={shareEmail}
                onChange={(e) => setShareEmail(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowShareDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleShareSubmit} className="bg-orange-600 hover:bg-orange-700">
              Share
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
