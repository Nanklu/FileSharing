package com.example.fileshare.controller;

import com.example.fileshare.dto.FileResponse;
import com.example.fileshare.dto.MessageResponse;
import com.example.fileshare.dto.ShareFileRequest;
import com.example.fileshare.exception.ResourceNotFoundException;
import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.SharedFile;
import com.example.fileshare.model.User;
import com.example.fileshare.service.FileService;
import com.example.fileshare.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/files")
public class FileController {
    
    @Autowired
    private FileService fileService;
    
    @Autowired
    private UserService userService;
    
    @PostMapping("/upload")
    public ResponseEntity<FileResponse> uploadFile(
            @RequestParam("file") MultipartFile file,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        FileEntity fileEntity = fileService.storeFile(file, user);
        
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/files/download/")
                .path(fileEntity.getId().toString())
                .toUriString();
        
        FileResponse fileResponse = new FileResponse(
                fileEntity.getId(),
                fileEntity.getName(),
                fileDownloadUri,
                file.getContentType(),
                file.getSize(),
                fileEntity.isStarred(),
                fileEntity.getCreatedAt(),
                fileEntity.getUpdatedAt()
        );
        
        return ResponseEntity.ok(fileResponse);
    }
    
    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId, HttpServletRequest request) {
        FileEntity fileEntity = fileService.getFileById(fileId)
                .orElseThrow(() -> new ResourceNotFoundException("File not found with id " + fileId));
        
        Resource resource = fileService.loadFileAsResource(fileEntity.getPath());
        
        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            System.out.println("Could not determine file type.");
        }
        
        // Fallback to the default content type if type could not be determined
        if (contentType == null) {
            contentType = "application/octet-stream";
        }
        
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileEntity.getName() + "\"")
                .body(resource);
    }
    
    @GetMapping("/my-files")
    public ResponseEntity<List<FileResponse>> getMyFiles(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<FileEntity> files = fileService.getFilesByOwner(user);
        
        List<FileResponse> fileResponses = files.stream()
                .map(this::mapToFileResponse)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(fileResponses);
    }
    
    @GetMapping("/starred")
    public ResponseEntity<List<FileResponse>> getStarredFiles(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<FileEntity> files = fileService.getStarredFiles(user);
        
        List<FileResponse> fileResponses = files.stream()
                .map(this::mapToFileResponse)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(fileResponses);
    }
    
    @GetMapping("/shared-with-me")
    public ResponseEntity<List<FileResponse>> getSharedWithMe(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<FileEntity> files = fileService.getSharedWithUser(user);
        
        List<FileResponse> fileResponses = files.stream()
                .map(this::mapToFileResponse)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(fileResponses);
    }
    
    @PutMapping("/{id}/star")
    public ResponseEntity<FileResponse> toggleStarFile(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        FileEntity file = fileService.getFileById(id)
                .orElseThrow(() -> new ResourceNotFoundException("File not found with id " + id));
        
        // Check if user is the owner
        if (!file.getOwner().getId().equals(user.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        file.setStarred(!file.isStarred());
        file = fileService.updateFile(file);
        
        return ResponseEntity.ok(mapToFileResponse(file));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<MessageResponse> deleteFile(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Optional<FileEntity> fileOpt = fileService.getFileById(id);
        
        if (fileOpt.isPresent()) {
            FileEntity file = fileOpt.get();
            
            // Check if user is the owner
            if (!file.getOwner().getId().equals(user.getId())) {
                return ResponseEntity.badRequest()
                        .body(new MessageResponse("You don't have permission to delete this file"));
            }
            
            fileService.deleteFile(id);
            return ResponseEntity.ok(new MessageResponse("File deleted successfully"));
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/{id}/share")
    public ResponseEntity<?> shareFile(
            @PathVariable Long id,
            @RequestBody ShareFileRequest shareRequest,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User currentUser = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        FileEntity file = fileService.getFileById(id)
                .orElseThrow(() -> new ResourceNotFoundException("File not found with id " + id));
        
        // Check if user is the owner
        if (!file.getOwner().getId().equals(currentUser.getId())) {
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("You don't have permission to share this file"));
        }
        
        User targetUser = userService.getUserByEmail(shareRequest.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Target user not found"));
        
        try {
            SharedFile sharedFile = fileService.shareFile(file, currentUser, targetUser);
            return ResponseEntity.ok(new MessageResponse("File shared successfully"));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(new MessageResponse(e.getMessage()));
        }
    }
    
    private FileResponse mapToFileResponse(FileEntity file) {
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/files/download/")
                .path(file.getId().toString())
                .toUriString();
        
        return new FileResponse(
                file.getId(),
                file.getName(),
                fileDownloadUri,
                file.getType(),
                file.getSize(),
                file.isStarred(),
                file.getCreatedAt(),
                file.getUpdatedAt()
        );
    }
}
