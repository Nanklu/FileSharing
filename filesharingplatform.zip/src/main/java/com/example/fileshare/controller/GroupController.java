package com.example.fileshare.controller;

import com.example.fileshare.dto.GroupRequest;
import com.example.fileshare.dto.GroupResponse;
import com.example.fileshare.dto.MessageResponse;
import com.example.fileshare.exception.ResourceNotFoundException;
import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.Group;
import com.example.fileshare.model.User;
import com.example.fileshare.service.FileService;
import com.example.fileshare.service.GroupService;
import com.example.fileshare.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/groups")
public class GroupController {
    
    @Autowired
    private GroupService groupService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private FileService fileService;
    
    @GetMapping
    public ResponseEntity<List<GroupResponse>> getAllGroups(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        List<Group> groups = groupService.getGroupsByMember(user);
        
        List<GroupResponse> groupResponses = groups.stream()
                .map(this::mapToGroupResponse)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(groupResponses);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<GroupResponse> getGroupById(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + id));
        
        // Check if user is a member
        if (!group.getMembers().contains(user)) {
            return ResponseEntity.badRequest().build();
        }
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @PostMapping
    public ResponseEntity<GroupResponse> createGroup(
            @Valid @RequestBody GroupRequest groupRequest,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = new Group();
        group.setName(groupRequest.getName());
        group.setCreator(user);
        
        group = groupService.createGroup(group);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<GroupResponse> updateGroup(
            @PathVariable Long id,
            @Valid @RequestBody GroupRequest groupRequest,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + id));
        
        // Check if user is the creator
        if (!group.getCreator().getId().equals(user.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        group.setName(groupRequest.getName());
        group = groupService.updateGroup(group);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<MessageResponse> deleteGroup(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User user = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + id));
        
        // Check if user is the creator
        if (!group.getCreator().getId().equals(user.getId())) {
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("You don't have permission to delete this group"));
        }
        
        groupService.deleteGroup(id);
        
        return ResponseEntity.ok(new MessageResponse("Group deleted successfully"));
    }
    
    @PostMapping("/{id}/members/{email}")
    public ResponseEntity<GroupResponse> addMember(
            @PathVariable Long id,
            @PathVariable String email,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User currentUser = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + id));
        
        // Check if user is the creator
        if (!group.getCreator().getId().equals(currentUser.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        User memberToAdd = userService.getUserByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email " + email));
        
        group = groupService.addMember(group, memberToAdd);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @DeleteMapping("/{id}/members/{email}")
    public ResponseEntity<GroupResponse> removeMember(
            @PathVariable Long id,
            @PathVariable String email,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User currentUser = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + id));
        
        // Check if user is the creator
        if (!group.getCreator().getId().equals(currentUser.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        User memberToRemove = userService.getUserByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email " + email));
        
        // Cannot remove the creator
        if (memberToRemove.getId().equals(group.getCreator().getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        group = groupService.removeMember(group, memberToRemove);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @PostMapping("/{groupId}/files/{fileId}")
    public ResponseEntity<GroupResponse> addFileToGroup(
            @PathVariable Long groupId,
            @PathVariable Long fileId,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User currentUser = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + groupId));
        
        FileEntity file = fileService.getFileById(fileId)
                .orElseThrow(() -> new ResourceNotFoundException("File not found with id " + fileId));
        
        // Check if user is the owner of the file
        if (!file.getOwner().getId().equals(currentUser.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        // Check if user is a member of the group
        if (!group.getMembers().contains(currentUser)) {
            return ResponseEntity.badRequest().build();
        }
        
        group = groupService.addFile(group, file);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    @DeleteMapping("/{groupId}/files/{fileId}")
    public ResponseEntity<GroupResponse> removeFileFromGroup(
            @PathVariable Long groupId,
            @PathVariable Long fileId,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        User currentUser = userService.getUserByEmail(userDetails.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        Group group = groupService.getGroupById(groupId)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with id " + groupId));
        
        FileEntity file = fileService.getFileById(fileId)
                .orElseThrow(() -> new ResourceNotFoundException("File not found with id " + fileId));
        
        // Check if user is the owner of the file or the creator of the group
        if (!file.getOwner().getId().equals(currentUser.getId()) && 
            !group.getCreator().getId().equals(currentUser.getId())) {
            return ResponseEntity.badRequest().build();
        }
        
        group = groupService.removeFile(group, file);
        
        return ResponseEntity.ok(mapToGroupResponse(group));
    }
    
    private GroupResponse mapToGroupResponse(Group group) {
        return new GroupResponse(
                group.getId(),
                group.getName(),
                group.getCreator().getId(),
                group.getCreator().getName(),
                group.getMembers().size(),
                group.getCreatedAt(),
                group.getUpdatedAt()
        );
    }
}
