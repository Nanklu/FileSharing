package com.example.fileshare.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class GroupResponse {
    private Long id;
    private String name;
    private Long creatorId;
    private String creatorName;
    private int memberCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
