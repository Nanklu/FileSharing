package com.example.fileshare.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ShareFileRequest {
    @NotBlank
    @Email
    private String email;
}
