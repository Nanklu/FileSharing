package com.example.fileshare.service;

import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.Group;
import com.example.fileshare.model.User;
import com.example.fileshare.repository.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroupService {
    
    @Autowired
    private GroupRepository groupRepository;
    
    public List<Group> getAllGroups() {
        return groupRepository.findAll();
    }
    
    public Optional<Group> getGroupById(Long id) {
        return groupRepository.findById(id);
    }
    
    public List<Group> getGroupsByCreator(User creator) {
        return groupRepository.findByCreator(creator);
    }
    
    public List<Group> getGroupsByMember(User member) {
        return groupRepository.findByMembersContaining(member);
    }
    
    public Group createGroup(Group group) {
        // Add creator as a member
        group.getMembers().add(group.getCreator());
        return groupRepository.save(group);
    }
    
    public Group updateGroup(Group group) {
        return groupRepository.save(group);
    }
    
    public void deleteGroup(Long id) {
        groupRepository.deleteById(id);
    }
    
    public Group addMember(Group group, User member) {
        group.getMembers().add(member);
        return groupRepository.save(group);
    }
    
    public Group removeMember(Group group, User member) {
        group.getMembers().remove(member);
        return groupRepository.save(group);
    }
    
    public Group addFile(Group group, FileEntity file) {
        group.getFiles().add(file);
        return groupRepository.save(group);
    }
    
    public Group removeFile(Group group, FileEntity file) {
        group.getFiles().remove(file);
        return groupRepository.save(group);
    }
}
