package com.example.fileshare.service;

import com.example.fileshare.config.FileStorageProperties;
import com.example.fileshare.exception.FileStorageException;
import com.example.fileshare.exception.ResourceNotFoundException;
import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.SharedFile;
import com.example.fileshare.model.User;
import com.example.fileshare.repository.FileRepository;
import com.example.fileshare.repository.SharedFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class FileService {
    
    private final Path fileStorageLocation;
    
    @Autowired
    private FileRepository fileRepository;
    
    @Autowired
    private SharedFileRepository sharedFileRepository;
    
    @Autowired
    public FileService(FileStorageProperties fileStorageProperties) {
        this.fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir())
                .toAbsolutePath().normalize();
        
        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }
    
    public FileEntity storeFile(MultipartFile file, User owner) {
        // Normalize file name
        String originalFileName = StringUtils.cleanPath(file.getOriginalFilename());
        
        try {
            // Check if the file's name contains invalid characters
            if (originalFileName.contains("..")) {
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + originalFileName);
            }
            
            // Generate a unique file name to prevent conflicts
            String fileExtension = "";
            if (originalFileName.contains(".")) {
                fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
            }
            String uniqueFileName = UUID.randomUUID().toString() + fileExtension;
            
            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileStorageLocation.resolve(uniqueFileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            
            // Create file entity
            FileEntity fileEntity = new FileEntity();
            fileEntity.setName(originalFileName);
            fileEntity.setType(file.getContentType());
            fileEntity.setSize(file.getSize());
            fileEntity.setPath(uniqueFileName);
            fileEntity.setOwner(owner);
            fileEntity.setStarred(false);
            
            return fileRepository.save(fileEntity);
        } catch (IOException ex) {
            throw new FileStorageException("Could not store file " + originalFileName + ". Please try again!", ex);
        }
    }
    
    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new ResourceNotFoundException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            throw new ResourceNotFoundException("File not found " + fileName, ex);
        }
    }
    
    public List<FileEntity> getFilesByOwner(User owner) {
        return fileRepository.findByOwner(owner);
    }
    
    public List<FileEntity> getStarredFiles(User owner) {
        return fileRepository.findByOwnerAndStarredTrue(owner);
    }
    
    public List<FileEntity> getSharedWithUser(User user) {
        return fileRepository.findSharedWithUser(user);
    }
    
    public List<FileEntity> getFilesInUserGroups(User user) {
        return fileRepository.findInUserGroups(user);
    }
    
    public Optional<FileEntity> getFileById(Long id) {
        return fileRepository.findById(id);
    }
    
    public FileEntity updateFile(FileEntity file) {
        return fileRepository.save(file);
    }
    
    public void deleteFile(Long id) {
        Optional<FileEntity> fileOpt = fileRepository.findById(id);
        if (fileOpt.isPresent()) {
            FileEntity file = fileOpt.get();
            
            // Delete the physical file
            try {
                Path filePath = this.fileStorageLocation.resolve(file.getPath()).normalize();
                Files.deleteIfExists(filePath);
            } catch (IOException ex) {
                throw new FileStorageException("Could not delete file " + file.getName(), ex);
            }
            
            // Delete the database record
            fileRepository.delete(file);
        }
    }
    
    public SharedFile shareFile(FileEntity file, User sharedBy, User sharedWith) {
        // Check if already shared
        if (sharedFileRepository.existsByFileAndSharedWith(file, sharedWith)) {
            throw new IllegalStateException("File already shared with this user");
        }
        
        SharedFile sharedFile = new SharedFile();
        sharedFile.setFile(file);
        sharedFile.setSharedBy(sharedBy);
        sharedFile.setSharedWith(sharedWith);
        
        return sharedFileRepository.save(sharedFile);
    }
    
    public List<SharedFile> getFilesSharedByUser(User user) {
        return sharedFileRepository.findBySharedBy(user);
    }
    
    public List<SharedFile> getFilesSharedWithUser(User user) {
        return sharedFileRepository.findBySharedWith(user);
    }
    
    public void unshareFile(Long sharedFileId) {
        sharedFileRepository.deleteById(sharedFileId);
    }
}
