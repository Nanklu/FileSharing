package com.example.fileshare.service;

import com.example.fileshare.model.User;
import com.example.fileshare.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private JwtTokenProvider tokenProvider;
    
    @Autowired
    private UserService userService;
    
    public String authenticateUser(String email, String password) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(email, password));
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        return tokenProvider.generateToken(authentication);
    }
    
    public User registerUser(User user) {
        if (userService.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email is already in use!");
        }
        
        return userService.createUser(user);
    }
}
