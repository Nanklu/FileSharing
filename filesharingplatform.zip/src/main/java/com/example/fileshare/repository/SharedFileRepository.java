package com.example.fileshare.repository;

import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.SharedFile;
import com.example.fileshare.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SharedFileRepository extends JpaRepository<SharedFile, Long> {
    List<SharedFile> findBySharedWith(User user);
    List<SharedFile> findBySharedBy(User user);
    List<SharedFile> findByFile(FileEntity file);
    boolean existsByFileAndSharedWith(FileEntity file, User user);
}
