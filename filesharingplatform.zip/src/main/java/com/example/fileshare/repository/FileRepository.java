package com.example.fileshare.repository;

import com.example.fileshare.model.FileEntity;
import com.example.fileshare.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends JpaRepository<FileEntity, Long> {
    List<FileEntity> findByOwner(User owner);
    List<FileEntity> findByOwnerAndStarredTrue(User owner);
    
    @Query("SELECT f FROM FileEntity f JOIN f.sharedWith s WHERE s.sharedWith = ?1")
    List<FileEntity> findSharedWithUser(User user);
    
    @Query("SELECT f FROM FileEntity f JOIN f.groups g JOIN g.members m WHERE m = ?1")
    List<FileEntity> findInUserGroups(User user);
}
